# PublicNoticeBoard
Complete Node Js CRUD Application with authentication, validation, access control

Framework used: Express

Middleware used: Express Session, Express validator, Express Message.

Database used : MongoDB(no-sql)

Mongoose object model for mongo db

Used Passport for user validation and connect-flash for passing messages to client.
